#ifndef CSLOLVERSION_H
#define CSLOLVERSION_H

namespace CSLOL {
    extern char const* VERSION;
    extern char const* COMMIT;
    extern char const* DATE;
}

#endif  // CSLOLVERSION_H
