#pragma once
#include <fmt/core.h>
#include <fmt/format.h>
#include <fmtlog.h>

#include <cstddef>
#include <cstdint>
#include <memory>
#include <span>

namespace lol {}
