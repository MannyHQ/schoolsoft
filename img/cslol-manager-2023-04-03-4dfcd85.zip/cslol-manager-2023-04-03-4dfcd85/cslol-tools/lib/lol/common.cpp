#include <lol/common.hpp>

using namespace lol;
